#include "stdafx.h"
#include "Place.h"


Place::Place()
{
	this->section = 0;
	this->shelf = 0;
	this->number = 0;
}
Place::Place(int section, int shelf, int number)
{
	this->section = section;
	this->shelf = shelf;
	this->number = number;
}

Place& Place::operator=(const Place& other)
{
	if (this != &other)
	{
		this->section = other.section;
		this->shelf = other.shelf;
		this->number = other.number;
	}
	return *this;
}

int Place::get_section() const
{
	return this->section;
}
int Place::get_shelf() const
{
	return this->shelf;
}
int Place::get_number() const
{
	return this->number;
}

void Place::set_section(int section)
{
	this->section = section;
}
void Place::set_shelf(int shelf)
{
	this->shelf = shelf;
}
void Place::get_number(int number)
{
	this->number = number;
}
