#pragma once
#include<iostream>
#include"Date.h"
#include"Product.h"
#include"Place.h"
#include"Command.h"
#include<vector>

class Storage
{
private:
	int volume;
	Product* products;
	int size;
	int capacity;
	std::vector<Command> commands;
public:
	Storage();
	Storage(const Storage& other);

	Storage& operator= (const Storage& other);

	~Storage();

	void print();
	/*void add(const Product product);
	void remove(const std::string name, int quantity);
	void log(const Date from, const Date to);
	void clean();*/
};

