#pragma once
class Place
{
private:
	int section;
	int shelf;
	int number;
public:
	Place();
	Place(int section, int shelf, int number);
	Place& operator=(const Place& other);

	int get_section() const;
	int get_shelf() const;
	int get_number() const;

	void set_section(int section);
	void set_shelf(int shelf);
	void get_number(int number);

};

