#include "stdafx.h"
#include "Storage.h"


Storage::Storage()
{
	this->volume = 500;
	this->products = new Product[this->capacity];
	this->capacity = 100;
	this->size = 0;
}
Storage::Storage(const Storage& other)
{
	this->volume = other.volume;
	delete[] this->products;
	this->products = new Product[other.capacity];
	this->size = other.size;
	this->capacity = other.capacity;
	for (size_t i = 0; i < other.size; i++)
	{
		this->products[i] = other.products[i];
	}
	this->commands = other.commands;
}

Storage& Storage::operator= (const Storage& other)
{
	if (this != &other)
	{
		this->volume = other.volume;
		delete[] this->products;
		this->products = new Product[other.capacity];
		this->size = other.size;
		this->capacity = other.capacity;
		for (size_t i = 0; i < other.size; i++)
		{
			this->products[i] = other.products[i];
		}
		this->commands = other.commands;
	}

	return *this;
}

Storage::~Storage()
{
	delete[] this->products;
}

void Storage::print()
{
	for (size_t i = 0; i < this->size; i++)
	{
		std::cout << "Product: " << this->products[i].get_name() << std::endl;
		std::cout << "Expiration date: " << this->products[i].get_expirationDate().get_day() 			
			<< "/" << this->products[i].get_expirationDate().get_month() 
			<< "/" << this->products[i].get_expirationDate().get_year() << std::endl;
		if (this->products[i].get_unit())
		{
			std::cout << "Unit: kilograms" << std::endl;
		}
		else
		{
			std::cout << "Unit: liters" << std::endl;
		}
		std::cout << "Place in storage: "
			<< "section: " << this->products[i].get_placeInStorage().get_section() << "/"
			<< "shelf: " << this->products[i].get_placeInStorage().get_shelf() << "/"
			<< "munber: " << this->products[i].get_placeInStorage().get_number() << std::endl;
		std::cout << "Qantity: " << this->products[i].get_quantity() << std::endl;
		std::cout << "Note: " << this->products[i].get_note() << std::endl;
		std::cout << std::endl;
	}
}