var annotated_dup =
[
    [ "Command", "class_command.html", "class_command" ],
    [ "Date", "class_date.html", "class_date" ],
    [ "Place", "class_place.html", "class_place" ],
    [ "Product", "class_product.html", "class_product" ],
    [ "Storage", "class_storage.html", "class_storage" ]
];