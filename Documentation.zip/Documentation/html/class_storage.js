var class_storage =
[
    [ "Storage", "class_storage.html#a80ef6af5e4c9fd4424ae16e808d05291", null ],
    [ "add", "class_storage.html#af661b341e3db2afdd857f3395230a49a", null ],
    [ "clean", "class_storage.html#abab522b400d5584c63f22344205f5027", null ],
    [ "countLeapYears", "class_storage.html#ae2a8163311a2ad8c732abc2fdfa8133a", null ],
    [ "daysBetweenTwoDates", "class_storage.html#aa082b9e881a9229ca4f997e359a095c7", null ],
    [ "generate_places", "class_storage.html#af40db1f3a14fc7a6ef1191652cd25ca8", null ],
    [ "get_currentDate", "class_storage.html#a8280556e359cbfbf28adb97649816702", null ],
    [ "log", "class_storage.html#a2a46b374fc188c585a57a10a6fe1bd4d", null ],
    [ "print", "class_storage.html#a73df5f67fd76f334e3511b2850882974", null ],
    [ "print_on_file", "class_storage.html#aac507cb42c5556d93e05066b5404e2a3", null ],
    [ "remove", "class_storage.html#a134469d697be6e9c7f82058a6da6ecad", null ],
    [ "set_volume", "class_storage.html#a292246f1c4b719a112638bdc73109664", null ],
    [ "commands", "class_storage.html#ac70f9c3b5b46699ea541cb3a25693f20", null ],
    [ "places", "class_storage.html#a980c430120597bdbb8ace78ba5330158", null ],
    [ "volume", "class_storage.html#ad7902462fa9d7c09c5fd989e302c21d8", null ]
];