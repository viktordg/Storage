var searchData=
[
  ['section_186',['section',['../class_place.html#ac83bdec171f39b5976ac832ccf0e922c',1,'Place']]],
  ['shelf_187',['shelf',['../class_place.html#a7e8f242bfd96a4ae4a08c7d395e7644c',1,'Place']]]
];
