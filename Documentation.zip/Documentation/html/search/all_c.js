var searchData=
[
  ['remove_64',['remove',['../class_storage.html#a134469d697be6e9c7f82058a6da6ecad',1,'Storage']]]
];
