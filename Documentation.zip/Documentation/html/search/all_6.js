var searchData=
[
  ['log_38',['log',['../class_storage.html#a2a46b374fc188c585a57a10a6fe1bd4d',1,'Storage']]]
];
