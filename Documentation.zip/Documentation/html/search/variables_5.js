var searchData=
[
  ['name_180',['name',['../class_product.html#a6f88e6ff8cb26b1cce49a41e72e4fcb8',1,'Product']]],
  ['note_181',['note',['../class_product.html#a167e001e3a14c62fa7368b93f9b147dd',1,'Product']]],
  ['number_182',['number',['../class_place.html#a830d0cbd6118337e27fa3952c04df72d',1,'Place']]]
];
