var searchData=
[
  ['places_183',['places',['../class_storage.html#a980c430120597bdbb8ace78ba5330158',1,'Storage']]],
  ['products_184',['products',['../class_place.html#ac22598f53df4251a07736cc16de1cc50',1,'Place']]]
];
