var searchData=
[
  ['add_0',['add',['../class_storage.html#af661b341e3db2afdd857f3395230a49a',1,'Storage']]],
  ['add_5fproduct_1',['add_product',['../class_place.html#af595ae1fb6811e5384340fdecfb75b50',1,'Place']]]
];
