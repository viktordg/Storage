var searchData=
[
  ['expirationdate_176',['expirationDate',['../class_product.html#a2ff85a008d3fa1a87e3da86467ed6a31',1,'Product']]]
];
