var searchData=
[
  ['goesinstorage_177',['goesInStorage',['../class_product.html#a9703c835bc2f66c0101755e0aed24468',1,'Product']]]
];
