var class_place =
[
    [ "Place", "class_place.html#ab5ae86c31e3a4c91800fb396d38e7a2b", null ],
    [ "Place", "class_place.html#a2f47bf8a9320cfa5e74229b742f86301", null ],
    [ "add_product", "class_place.html#af595ae1fb6811e5384340fdecfb75b50", null ],
    [ "get_current_volume", "class_place.html#a296b3568f23c9daa916b6deb3b6245b9", null ],
    [ "get_number", "class_place.html#abcacb7c6a6c953c6a4e4759b85318210", null ],
    [ "get_products", "class_place.html#ae7f0023d4d764138b9741c0f741ec739", null ],
    [ "get_section", "class_place.html#a0c227aafaa1c508078dc3c07c17d04af", null ],
    [ "get_shelf", "class_place.html#a6e28bffa98a3fbfbc69fe5724494286b", null ],
    [ "get_volume", "class_place.html#a3ec453e09ac58b807f9095a46c755012", null ],
    [ "set_current_volume", "class_place.html#a5adf99ff0c8f13c918719a57e595f2c0", null ],
    [ "set_number", "class_place.html#a02d51d6d7576dccf4a551af3dedf7672", null ],
    [ "set_products", "class_place.html#af495e78f80062f75e48e82224ff63134", null ],
    [ "set_section", "class_place.html#a00a4962b81cfc86cd5bf7e182bd1b55d", null ],
    [ "set_shelf", "class_place.html#a4e9bf9dde239d4569daddca8e4a58850", null ],
    [ "set_volume", "class_place.html#a77b8464a08e294bf39786bfa54e4258a", null ],
    [ "current_volume", "class_place.html#afd0fb3fb3dadb6c339bd8577261e553c", null ],
    [ "number", "class_place.html#a830d0cbd6118337e27fa3952c04df72d", null ],
    [ "products", "class_place.html#ac22598f53df4251a07736cc16de1cc50", null ],
    [ "section", "class_place.html#ac83bdec171f39b5976ac832ccf0e922c", null ],
    [ "shelf", "class_place.html#a7e8f242bfd96a4ae4a08c7d395e7644c", null ],
    [ "volume", "class_place.html#a04282a657b721411f4f203d892eb1098", null ]
];